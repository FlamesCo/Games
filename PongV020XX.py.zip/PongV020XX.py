import pygame

pygame.init()

# Set up the display
WIDTH = 800
HEIGHT = 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Pong")

# Create the Paddle and Ball Classes
class Paddle(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((10, 100))
        self.image.fill((255, 255, 255))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.speed = 5

    def move_up(self):
        self.rect.y -= self.speed

    def move_down(self):
        self.rect.y += self.speed

class Ball(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((10, 10))
        self.image.fill((255, 255, 255))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.speed_x = 5
        self.speed_y = 5

    def update(self):
        self.rect.x += self.speed_x
        self.rect.y += self.speed_y

        # Bounce off walls
        if self.rect.y <= 0 or self.rect.y + self.rect.height >= HEIGHT:
            self.speed_y = -self.speed_y

        # Reset ball position if it goes off screen
        if self.rect.x <= 0 or self.rect.x + self.rect.width >= WIDTH:
            self.rect.x = WIDTH // 2 - self.rect.width // 2
            self.rect.y = HEIGHT // 2 - self.rect.height // 2
            self.speed_x = -self.speed_x
            self.speed_y = -self.speed_y

# Create the paddles and ball
left_paddle = Paddle(50, HEIGHT // 2 - 50)
right_paddle = Paddle(WIDTH - 60, HEIGHT // 2 - 50)
ball = Ball(WIDTH // 2 - 5, HEIGHT // 2 - 5)

# Create sprite groups
all_sprites = pygame.sprite.Group()
all_sprites.add(left_paddle, right_paddle, ball)

# Set up clock
clock = pygame.time.Clock()

# Game loop
running = True
while running:
    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # AI controls right paddle
    if ball.rect.x > WIDTH // 2:
        if ball.rect.y < right_paddle.rect.y:
            right_paddle.move_up()
        elif ball.rect.y > right_paddle.rect.y + right_paddle.rect.height:
            right_paddle.move_down()

    # Mouse controls left paddle
    mouse_pos = pygame.mouse.get_pos()
    if mouse_pos[1] > left_paddle.rect.y:
        left_paddle.move_down()
    elif mouse_pos[1] < left_paddle.rect.y:
        left_paddle.move_up()

    # Update sprites
    all_sprites.update()

    # Check for collisions
    if pygame.sprite.collide_rect(ball, left_paddle) or pygame.sprite.collide_rect(ball, right_paddle):
        ball.speed_x = -ball.speed_x

    # Draw screen
    screen.fill((0, 0, 0))
    all_sprites.draw(screen)
    pygame.display.flip()

    # Set the frame rate
    clock.tick(60)

# Quit Pygame
pygame.quit()
